<?php
require_once "config.php"; require_login(); if(!is_admin()){ http_response_code(403); die("Forbidden"); }
$action = $_GET['action'] ?? 'list';

if ($action==='create' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u = trim($_POST['username'] ?? '');
  $p = $_POST['password'] ?? '';
  $r = $_POST['role'] ?? 'receptionist';
  if ($u && $p){
    $stmt=$mysqli->prepare("INSERT INTO users (username,password_hash,role) VALUES (?,?,?)");
    $stmt->bind_param("sss",$u,$p,$r); // plain text store
    $stmt->execute();
    header("Location: users.php"); exit;
  }
}
if ($action==='delete' && isset($_GET['id'])){
  $id = (int)$_GET['id'];
  $me = (int)(current_user()['id'] ?? 0);
  if ($id !== $me){
    $stmt=$mysqli->prepare("DELETE FROM users WHERE id=?");
    $stmt->bind_param("i",$id);
    $stmt->execute();
  }
  header("Location: users.php"); exit;
}

include "header.php"; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Users</h3>
  <button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#createForm">Add User</button>
</div>

<div id="createForm" class="collapse mb-3">
  <div class="card card-body">
    <form method="post" action="users.php?action=create">
      <div class="row g-3">
        <div class="col-md-4"><label class="form-label">Username</label><input name="username" class="form-control" required></div>
        <div class="col-md-4"><label class="form-label">Password</label><input name="password" class="form-control" required></div>
        <div class="col-md-4">
          <label class="form-label">Role</label>
          <select name="role" class="form-select">
            <option value="receptionist">Receptionist</option>
            <option value="doctor">Doctor</option>
            <option value="admin">Admin</option>
          </select>
        </div>
      </div>
      <button class="btn btn-success mt-3">Create</button>
    </form>
  </div>
</div>

<div class="table-responsive">
<table class="table table-striped">
  <thead><tr><th>ID</th><th>Username</th><th>Role</th><th>Created</th><th></th></tr></thead>
  <tbody>
  <?php $res=$mysqli->query("SELECT * FROM users ORDER BY id DESC"); while($row=$res->fetch_assoc()): ?>
    <tr>
      <td><?php echo (int)$row['id']; ?></td>
      <td><?php echo htmlspecialchars($row['username']); ?></td>
      <td><?php echo htmlspecialchars($row['role']); ?></td>
      <td><?php echo htmlspecialchars($row['created_at']); ?></td>
      <td>
        <?php if((int)$row['id'] !== (int)(current_user()['id'] ?? 0)): ?>
        <a class="btn btn-sm btn-outline-danger" href="users.php?action=delete&id=<?php echo (int)$row['id']; ?>" onclick="return confirm('Delete user?');">Delete</a>
        <?php endif; ?>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
</div>
<?php include "footer.php"; ?>
