-- Run inside database `hms`
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS doctors;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','receptionist','doctor') NOT NULL DEFAULT 'receptionist',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  dob DATE NOT NULL,
  gender ENUM('Male','Female','Other') NOT NULL,
  phone VARCHAR(20),
  address VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE doctors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  specialty VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(120),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  appt_date DATE NOT NULL,
  appt_time TIME NOT NULL,
  status ENUM('Scheduled','Completed','Cancelled') NOT NULL DEFAULT 'Scheduled',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_p FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  CONSTRAINT fk_d FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Demo users (plain-text passwords for compatibility with older PHP)
INSERT INTO users (username, password_hash, role) VALUES
('admin','admin123','admin'),
('recep','recep123','receptionist'),
('doc','doc123','doctor');

-- Seed some doctors & patients
INSERT INTO doctors (name, specialty, phone, email) VALUES
('Dr. Asha Verma','Cardiology','9990011001','asha@example.com'),
('Dr. Rohan Iyer','Orthopedics','9990011002','rohan@example.com'),
('Dr. Neha Shah','Dermatology','9990011003','neha@example.com');

INSERT INTO patients (name, dob, gender, phone, address) VALUES
('Sanjay Kumar','1990-03-12','Male','9876543210','Pune'),
('Priya Patel','1988-07-25','Female','9876500000','Mumbai'),
('Anil Gupta','1979-11-05','Male','9123456789','Nagpur');

-- Sample appointments
INSERT INTO appointments (patient_id, doctor_id, appt_date, appt_time, status, notes) VALUES
(1,1, DATE_ADD(CURDATE(), INTERVAL 0 DAY), '10:00:00','Scheduled','Follow-up'),
(2,2, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '11:30:00','Scheduled','Knee pain'),
(3,3, DATE_ADD(CURDATE(), INTERVAL -1 DAY), '09:15:00','Completed','Rash check');
