<?php
require_once "config.php"; require_login();
$action = $_GET['action'] ?? 'list';

// Create
if ($action==='create' && $_SERVER['REQUEST_METHOD']==='POST'){
  $stmt=$mysqli->prepare("INSERT INTO appointments (patient_id,doctor_id,appt_date,appt_time,status,notes) VALUES (?,?,?,?,?,?)");
  $stmt->bind_param("iissss", $_POST['patient_id'], $_POST['doctor_id'], $_POST['appt_date'], $_POST['appt_time'], $_POST['status'], $_POST['notes']);
  $stmt->execute(); header("Location: appointments.php"); exit;
}
// Update
if ($action==='update' && $_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['id'])){
  $id=(int)$_GET['id'];
  $stmt=$mysqli->prepare("UPDATE appointments SET patient_id=?, doctor_id=?, appt_date=?, appt_time=?, status=?, notes=? WHERE id=?");
  $stmt->bind_param("iissssi", $_POST['patient_id'], $_POST['doctor_id'], $_POST['appt_date'], $_POST['appt_time'], $_POST['status'], $_POST['notes'], $id);
  $stmt->execute(); header("Location: appointments.php"); exit;
}
// Delete
if ($action==='delete' && isset($_GET['id'])){
  $id=(int)$_GET['id']; $stmt=$mysqli->prepare("DELETE FROM appointments WHERE id=?"); $stmt->bind_param("i",$id); $stmt->execute();
  header("Location: appointments.php"); exit;
}

// Data for selects
$patients = $mysqli->query("SELECT id,name FROM patients ORDER BY name");
$doctors = $mysqli->query("SELECT id,name,specialty FROM doctors ORDER BY name");

// Edit fetch
$editRow=null;
if ($action==='edit' && isset($_GET['id'])){
  $id=(int)$_GET['id'];
  $res=$mysqli->query("SELECT * FROM appointments WHERE id=$id"); $editRow=$res->fetch_assoc();
}

// Filter by date range / status
$from = $_GET['from'] ?? '';
$to   = $_GET['to'] ?? '';
$status = $_GET['status'] ?? '';
$where = [];
$params = [];
$types = "";
if ($from){ $where[]="a.appt_date>=?"; $params[]=$from; $types.="s"; }
if ($to){ $where[]="a.appt_date<=?"; $params[]=$to; $types+="s"; }
if ($status){ $where[]="a.status=?"; $params[]=$status; $types+="s"; }
$w = $where ? ("WHERE "+implode(" AND ",$where)) : "";
$sqlList = "SELECT a.*, p.name AS patient, d.name AS doctor, d.specialty
            FROM appointments a
            JOIN patients p ON p.id=a.patient_id
            JOIN doctors d ON d.id=a.doctor_id
            $w
            ORDER BY a.appt_date DESC, a.appt_time DESC";
$stmt=$mysqli->prepare($sqlList);
if ($where){ $stmt->bind_param($types, ...$params); }
$stmt->execute(); $list=$stmt->get_result();

include "header.php"; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Appointments</h3>
  <form class="row g-2" method="get">
    <div class="col-auto"><input type="date" name="from" class="form-control form-control-sm" value="<?php echo htmlspecialchars($from); ?>" placeholder="From"></div>
    <div class="col-auto"><input type="date" name="to" class="form-control form-control-sm" value="<?php echo htmlspecialchars($to); ?>" placeholder="To"></div>
    <div class="col-auto">
      <select name="status" class="form-select form-select-sm">
        <option value="">All</option>
        <?php foreach(['Scheduled','Completed','Cancelled'] as $st){ $sel=$status===$st?'selected':''; echo "<option $sel>$st</option>"; } ?>
      </select>
    </div>
    <div class="col-auto"><button class="btn btn-sm btn-outline-secondary">Filter</button></div>
  </form>
  <button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#createForm"><?php echo $editRow?'Edit Appointment':'Add Appointment'; ?></button>
</div>

<div id="createForm" class="collapse show mb-3">
  <div class="card card-body">
    <form method="post" action="appointments.php?action=<?php echo $editRow?'update&id='.(int)$editRow['id']:'create'; ?>">
      <div class="row g-3">
        <div class="col-md-3">
          <label class="form-label">Patient</label>
          <select name="patient_id" class="form-select" required>
          <?php $selP = $editRow['patient_id'] ?? 0; mysqli_data_seek($patients,0);
          while($p=$patients->fetch_assoc()): $s=$selP==(int)$p['id']?'selected':''; ?>
            <option value="<?php echo (int)$p['id']; ?>" <?php echo $s; ?>><?php echo htmlspecialchars($p['name']); ?></option>
          <?php endwhile; ?>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">Doctor</label>
          <select name="doctor_id" class="form-select" required>
          <?php $selD = $editRow['doctor_id'] ?? 0; mysqli_data_seek($doctors,0);
          while($d=$doctors->fetch_assoc()): $s=$selD==(int)$d['id']?'selected':''; ?>
            <option value="<?php echo (int)$d['id']; ?>" <?php echo $s; ?>><?php echo htmlspecialchars($d['name']." (".$d['specialty'].")"); ?></option>
          <?php endwhile; ?>
          </select>
        </div>
        <div class="col-md-2"><label class="form-label">Date</label><input type="date" name="appt_date" class="form-control" required value="<?php echo htmlspecialchars($editRow['appt_date'] ?? ''); ?>"></div>
        <div class="col-md-2"><label class="form-label">Time</label><input type="time" name="appt_time" class="form-control" required value="<?php echo htmlspecialchars($editRow['appt_time'] ?? ''); ?>"></div>
        <div class="col-md-2">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <?php $cur=$editRow['status'] ?? 'Scheduled'; foreach(['Scheduled','Completed','Cancelled'] as $st){ $s=$cur===$st?'selected':''; echo "<option $s>$st</option>"; } ?>
          </select>
        </div>
        <div class="col-12"><label class="form-label">Notes</label><textarea name="notes" class="form-control" rows="2"><?php echo htmlspecialchars($editRow['notes'] ?? ''); ?></textarea></div>
      </div>
      <button class="btn btn-success mt-3"><?php echo $editRow?'Update':'Save'; ?></button>
      <?php if($editRow): ?><a class="btn btn-secondary mt-3" href="appointments.php">Cancel</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="table-responsive">
<table class="table table-striped">
  <thead><tr><th>ID</th><th>Date</th><th>Time</th><th>Patient</th><th>Doctor</th><th>Status</th><th>Notes</th><th></th></tr></thead>
  <tbody>
  <?php while($row=$list->fetch_assoc()): ?>
    <tr>
      <td><?php echo (int)$row['id']; ?></td>
      <td><?php echo htmlspecialchars($row['appt_date']); ?></td>
      <td><?php echo htmlspecialchars($row['appt_time']); ?></td>
      <td><?php echo htmlspecialchars($row['patient']); ?></td>
      <td><?php echo htmlspecialchars($row['doctor']." (".$row['specialty'].")"); ?></td>
      <td><?php echo htmlspecialchars($row['status']); ?></td>
      <td><?php echo nl2br(htmlspecialchars($row['notes'])); ?></td>
      <td>
        <a class="btn btn-sm btn-outline-primary" href="appointments.php?action=edit&id=<?php echo (int)$row['id']; ?>">Edit</a>
        <a class="btn btn-sm btn-outline-danger" href="appointments.php?action=delete&id=<?php echo (int)$row['id']; ?>" onclick="return confirm('Delete appointment?');">Delete</a>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
</div>
<?php include "footer.php"; ?>
