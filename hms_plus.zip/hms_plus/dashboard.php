<?php
require_once "config.php"; require_login();
// counts
$counts = [];
foreach (['patients','doctors','appointments'] as $t){
  $r = $mysqli->query("SELECT COUNT(*) c FROM $t");
  $counts[$t] = (int)($r ? $r->fetch_assoc()['c'] : 0);
}
// today's appointments
$today = date('Y-m-d');
$sqlToday = "SELECT a.id, a.appt_date, a.appt_time, a.status, p.name AS patient, d.name AS doctor
             FROM appointments a
             JOIN patients p ON p.id=a.patient_id
             JOIN doctors d ON d.id=a.doctor_id
             WHERE a.appt_date=?
             ORDER BY a.appt_time ASC";
$stmt=$mysqli->prepare($sqlToday);
$stmt->bind_param("s",$today);
$stmt->execute();
$todayRes=$stmt->get_result();
include "header.php";
?>
<h3 class="mb-3">Dashboard</h3>
<div class="row g-3 mb-4">
  <div class="col-md-4"><div class="card"><div class="card-body">
    <h6>Patients</h6><div class="display-6"><?php echo $counts['patients']; ?></div>
    <a class="btn btn-sm btn-outline-primary" href="patients.php">Manage</a>
  </div></div></div>
  <div class="col-md-4"><div class="card"><div class="card-body">
    <h6>Doctors</h6><div class="display-6"><?php echo $counts['doctors']; ?></div>
    <a class="btn btn-sm btn-outline-primary" href="doctors.php">Manage</a>
  </div></div></div>
  <div class="col-md-4"><div class="card"><div class="card-body">
    <h6>Appointments</h6><div class="display-6"><?php echo $counts['appointments']; ?></div>
    <a class="btn btn-sm btn-outline-primary" href="appointments.php">Manage</a>
  </div></div></div>
</div>

<div class="card">
  <div class="card-header">Today's Appointments (<?php echo htmlspecialchars($today); ?>)</div>
  <div class="table-responsive">
  <table class="table table-striped mb-0">
    <thead><tr><th>#</th><th>Time</th><th>Patient</th><th>Doctor</th><th>Status</th></tr></thead>
    <tbody>
    <?php if($todayRes && $todayRes->num_rows): while($row=$todayRes->fetch_assoc()): ?>
      <tr>
        <td><?php echo (int)$row['id']; ?></td>
        <td><?php echo htmlspecialchars($row['appt_time']); ?></td>
        <td><?php echo htmlspecialchars($row['patient']); ?></td>
        <td><?php echo htmlspecialchars($row['doctor']); ?></td>
        <td><?php echo htmlspecialchars($row['status']); ?></td>
      </tr>
    <?php endwhile; else: ?>
      <tr><td colspan="5" class="text-center text-muted">No appointments today.</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>
<?php include "footer.php"; ?>
