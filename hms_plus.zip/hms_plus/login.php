<?php
require_once "config.php";
if (is_logged_in()) { header("Location: dashboard.php"); exit; }
$error = null;
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $username = trim($_POST['username'] ?? '');
  $password = $_POST['password'] ?? '';
  $stmt = $mysqli->prepare("SELECT id,username,password_hash,role FROM users WHERE username=?");
  $stmt->bind_param("s",$username);
  $stmt->execute();
  $res = $stmt->get_result();
  if ($row = $res->fetch_assoc()) {
    // Plain-text password check for compatibility with older PHP
    if ($password === $row['password_hash']) {
      $_SESSION['user'] = ['id'=>$row['id'],'username'=>$row['username'],'role'=>$row['role']];
      header("Location: dashboard.php"); exit;
    }
  }
  $error = "Invalid credentials";
}
include "header.php"; ?>
<div class="row justify-content-center">
  <div class="col-md-4">
    <h3 class="mb-3">Login</h3>
    <?php if($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input name="username" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button class="btn btn-primary w-100">Login</button>
      <div class="form-text mt-2">Demo: admin/admin123, recep/recep123, doc/doc123</div>
    </form>
  </div>
</div>
<?php include "footer.php"; ?>
