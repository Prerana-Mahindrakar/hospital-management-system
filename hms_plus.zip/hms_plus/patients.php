<?php
require_once "config.php"; require_login();
$action = $_GET['action'] ?? 'list';

// Create
if ($action==='create' && $_SERVER['REQUEST_METHOD']==='POST'){
  $stmt=$mysqli->prepare("INSERT INTO patients (name,dob,gender,phone,address) VALUES (?,?,?,?,?)");
  $stmt->bind_param("sssss", $_POST['name'], $_POST['dob'], $_POST['gender'], $_POST['phone'], $_POST['address']);
  $stmt->execute(); header("Location: patients.php"); exit;
}
// Update
if ($action==='update' && $_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['id'])){
  $id=(int)$_GET['id'];
  $stmt=$mysqli->prepare("UPDATE patients SET name=?, dob=?, gender=?, phone=?, address=? WHERE id=?");
  $stmt->bind_param("sssssi", $_POST['name'], $_POST['dob'], $_POST['gender'], $_POST['phone'], $_POST['address'], $id);
  $stmt->execute(); header("Location: patients.php"); exit;
}
// Delete
if ($action==='delete' && isset($_GET['id'])){
  $id=(int)$_GET['id']; $stmt=$mysqli->prepare("DELETE FROM patients WHERE id=?"); $stmt->bind_param("i",$id); $stmt->execute();
  header("Location: patients.php"); exit;
}

// Edit fetch
$editRow=null;
if ($action==='edit' && isset($_GET['id'])){
  $id=(int)$_GET['id']; $r=$mysqli->query("SELECT * FROM patients WHERE id=$id"); $editRow=$r->fetch_assoc();
}

// Search
$q = trim($_GET['q'] ?? '');
$where = $q ? "WHERE name LIKE CONCAT('%',?,'%') OR phone LIKE CONCAT('%',?,'%')" : "";
$sql = "SELECT * FROM patients $where ORDER BY id DESC";
$stmt = $mysqli->prepare($sql);
if ($q){ $stmt->bind_param("ss",$q,$q); }
$stmt->execute(); $list = $stmt->get_result();

include "header.php"; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Patients</h3>
  <div>
    <form class="d-flex" method="get">
      <input type="text" name="q" class="form-control form-control-sm me-2" placeholder="Search name/phone" value="<?php echo htmlspecialchars($q); ?>">
      <button class="btn btn-sm btn-outline-secondary">Search</button>
    </form>
  </div>
  <button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#createForm"><?php echo $editRow?'Edit Patient':'Add Patient'; ?></button>
</div>

<div id="createForm" class="collapse show mb-3">
  <div class="card card-body">
    <form method="post" action="patients.php?action=<?php echo $editRow?'update&id='.(int)$editRow['id']:'create'; ?>">
      <div class="row g-3">
        <div class="col-md-4"><label class="form-label">Name</label><input name="name" class="form-control" required value="<?php echo htmlspecialchars($editRow['name'] ?? ''); ?>"></div>
        <div class="col-md-3"><label class="form-label">DOB</label><input type="date" name="dob" class="form-control" required value="<?php echo htmlspecialchars($editRow['dob'] ?? ''); ?>"></div>
        <div class="col-md-2"><label class="form-label">Gender</label>
          <select name="gender" class="form-select">
            <?php $g= $editRow['gender'] ?? 'Male'; foreach(['Male','Female','Other'] as $x){ $sel=$g===$x?'selected':''; echo "<option $sel>$x</option>"; } ?>
          </select>
        </div>
        <div class="col-md-3"><label class="form-label">Phone</label><input name="phone" class="form-control" value="<?php echo htmlspecialchars($editRow['phone'] ?? ''); ?>"></div>
        <div class="col-12"><label class="form-label">Address</label><input name="address" class="form-control" value="<?php echo htmlspecialchars($editRow['address'] ?? ''); ?>"></div>
      </div>
      <button class="btn btn-success mt-3"><?php echo $editRow?'Update':'Save'; ?></button>
      <?php if($editRow): ?><a class="btn btn-secondary mt-3" href="patients.php">Cancel</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="table-responsive">
<table class="table table-striped">
  <thead><tr><th>ID</th><th>Name</th><th>DOB</th><th>Gender</th><th>Phone</th><th>Address</th><th>Created</th><th></th></tr></thead>
  <tbody>
  <?php while($row=$list->fetch_assoc()): ?>
    <tr>
      <td><?php echo (int)$row['id']; ?></td>
      <td><?php echo htmlspecialchars($row['name']); ?></td>
      <td><?php echo htmlspecialchars($row['dob']); ?></td>
      <td><?php echo htmlspecialchars($row['gender']); ?></td>
      <td><?php echo htmlspecialchars($row['phone']); ?></td>
      <td><?php echo htmlspecialchars($row['address']); ?></td>
      <td><?php echo htmlspecialchars($row['created_at']); ?></td>
      <td>
        <a class="btn btn-sm btn-outline-primary" href="patients.php?action=edit&id=<?php echo (int)$row['id']; ?>">Edit</a>
        <a class="btn btn-sm btn-outline-danger" href="patients.php?action=delete&id=<?php echo (int)$row['id']; ?>" onclick="return confirm('Delete patient?');">Delete</a>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
</div>
<?php include "footer.php"; ?>
