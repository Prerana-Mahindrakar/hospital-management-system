<?php
// Database config (XAMPP defaults)
$DB_HOST = "localhost:4306";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "hms";

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_errno) {
    die("Failed DB connect: " . $mysqli->connect_error);
}
$mysqli->set_charset("utf8mb4");

session_start();

function is_logged_in(){ return isset($_SESSION['user']); }
function current_user(){ return $_SESSION['user'] ?? null; }
function is_admin(){ return (current_user()['role'] ?? '') === 'admin'; }
function require_login(){
  if (!is_logged_in()) { header("Location: login.php"); exit; }
}
?>
