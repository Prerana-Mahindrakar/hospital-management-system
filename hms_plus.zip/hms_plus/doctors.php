<?php
require_once "config.php"; require_login();
$action = $_GET['action'] ?? 'list';

if ($action==='create' && $_SERVER['REQUEST_METHOD']==='POST'){
  $stmt=$mysqli->prepare("INSERT INTO doctors (name,specialty,phone,email) VALUES (?,?,?,?)");
  $stmt->bind_param("ssss", $_POST['name'], $_POST['specialty'], $_POST['phone'], $_POST['email']);
  $stmt->execute(); header("Location: doctors.php"); exit;
}
if ($action==='update' && $_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['id'])){
  $id=(int)$_GET['id'];
  $stmt=$mysqli->prepare("UPDATE doctors SET name=?, specialty=?, phone=?, email=? WHERE id=?");
  $stmt->bind_param("ssssi", $_POST['name'], $_POST['specialty'], $_POST['phone'], $_POST['email'], $id);
  $stmt->execute(); header("Location: doctors.php"); exit;
}
if ($action==='delete' && isset($_GET['id'])){
  $id=(int)$_GET['id']; $stmt=$mysqli->prepare("DELETE FROM doctors WHERE id=?"); $stmt->bind_param("i",$id); $stmt->execute();
  header("Location: doctors.php"); exit;
}
$editRow=null;
if ($action==='edit' && isset($_GET['id'])){
  $id=(int)$_GET['id']; $r=$mysqli->query("SELECT * FROM doctors WHERE id=$id"); $editRow=$r->fetch_assoc();
}
$spec = trim($_GET['specialty'] ?? '');
$where = $spec ? "WHERE specialty=?" : "";
$sql = "SELECT * FROM doctors $where ORDER BY id DESC";
$stmt=$mysqli->prepare($sql);
if ($spec){ $stmt->bind_param("s",$spec); }
$stmt->execute(); $list=$stmt->get_result();

$specs = $mysqli->query("SELECT DISTINCT specialty FROM doctors ORDER BY specialty ASC");

include "header.php"; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Doctors</h3>
  <form class="d-flex" method="get">
    <select name="specialty" class="form-select form-select-sm me-2">
      <option value="">All Specialties</option>
      <?php while($s=$specs->fetch_assoc()): $sel=($s['specialty']===$spec)?'selected':''; echo "<option $sel>".htmlspecialchars($s['specialty'])."</option>"; endwhile; ?>
    </select>
    <button class="btn btn-sm btn-outline-secondary">Filter</button>
  </form>
  <button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#createForm"><?php echo $editRow?'Edit Doctor':'Add Doctor'; ?></button>
</div>

<div id="createForm" class="collapse show mb-3">
  <div class="card card-body">
    <form method="post" action="doctors.php?action=<?php echo $editRow?'update&id='.(int)$editRow['id']:'create'; ?>">
      <div class="row g-3">
        <div class="col-md-4"><label class="form-label">Name</label><input name="name" class="form-control" required value="<?php echo htmlspecialchars($editRow['name'] ?? ''); ?>"></div>
        <div class="col-md-4"><label class="form-label">Specialty</label><input name="specialty" class="form-control" required value="<?php echo htmlspecialchars($editRow['specialty'] ?? ''); ?>"></div>
        <div class="col-md-2"><label class="form-label">Phone</label><input name="phone" class="form-control" value="<?php echo htmlspecialchars($editRow['phone'] ?? ''); ?>"></div>
        <div class="col-md-2"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($editRow['email'] ?? ''); ?>"></div>
      </div>
      <button class="btn btn-success mt-3"><?php echo $editRow?'Update':'Save'; ?></button>
      <?php if($editRow): ?><a class="btn btn-secondary mt-3" href="doctors.php">Cancel</a><?php endif; ?>
    </form>
  </div>
</div>

<div class="table-responsive">
<table class="table table-striped">
  <thead><tr><th>ID</th><th>Name</th><th>Specialty</th><th>Phone</th><th>Email</th><th>Created</th><th></th></tr></thead>
  <tbody>
  <?php while($row=$list->fetch_assoc()): ?>
    <tr>
      <td><?php echo (int)$row['id']; ?></td>
      <td><?php echo htmlspecialchars($row['name']); ?></td>
      <td><?php echo htmlspecialchars($row['specialty']); ?></td>
      <td><?php echo htmlspecialchars($row['phone']); ?></td>
      <td><?php echo htmlspecialchars($row['email']); ?></td>
      <td><?php echo htmlspecialchars($row['created_at']); ?></td>
      <td>
        <a class="btn btn-sm btn-outline-primary" href="doctors.php?action=edit&id=<?php echo (int)$row['id']; ?>">Edit</a>
        <a class="btn btn-sm btn-outline-danger" href="doctors.php?action=delete&id=<?php echo (int)$row['id']; ?>" onclick="return confirm('Delete doctor?');">Delete</a>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
</div>
<?php include "footer.php"; ?>
